package com.example.gallery.ui.splash;

/**
 * Created on 1/11/2023
 */
public interface SplashNavigator {
    void openLoginActivity();
    void openMainActivity();
}
