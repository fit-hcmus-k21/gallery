package com.example.gallery.ui.gridview;

public interface MediaItemNavigator {
}
